using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;

string endpoint = "<cosmos-endpoint>";
string key = "<cosmos-key>";